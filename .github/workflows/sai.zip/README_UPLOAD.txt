1) Social-ai repo > Add file > Upload files: drag the whole "social-content" FOLDER (from this zip, extracted). Commit.
2) Add file > Create new file. Name: .github/workflows/social-content.yml  -> paste social-content-workflow.yml text. Commit.
3) Actions tab > social-content > Run workflow.
